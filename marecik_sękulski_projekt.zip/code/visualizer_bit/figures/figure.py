class Figure:
    def __init__(self, data, options):
        self.data = data
        self.options = options
        self.artist = None
        self.to_be_removed = False
